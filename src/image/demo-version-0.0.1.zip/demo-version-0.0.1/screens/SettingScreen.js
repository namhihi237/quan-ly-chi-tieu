import React, {Component} from 'react';
import {Button, Text, View, Image} from 'react-native';
import {Container, Content, Icon} from 'native-base';
export default class SettingScreen extends Component {
  static navigationOptions = {
    swipeEnabled: true,
    tabBarIcon: ({tintColor}) => {
      return (
        <Image
          source={require('../image/settings.png')}
          style={{tintColor: tintColor, width: 26, height: 26}}></Image>
      );
    },
  };
  render() {
    return (
      <Container>
        <Content>
          <Text>Setting</Text>
        </Content>
      </Container>
    );
  }
}
