import React, {Component} from 'react';
import {Button, Text, View} from 'react-native';
import {Container, Content, Icon} from 'native-base';
import {createStackNavigator} from 'react-navigation-stack';
export default class DetailScreen extends Component {
  render() {
    return (
      <Container>
        <Content>
          <Text>Detail</Text>
        </Content>
      </Container>
    );
  }
}
