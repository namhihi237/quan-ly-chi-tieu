/**
 * @format
 */

import {AppRegistry} from 'react-native';
// import App from './App';
import {name as appName} from './app.json';
import SettingScreen from './screens/SettingScreen';
import HomeScreen from './screens/HomeScreen';
import DetailScreen from './screens/DetailScreen';
import {createStackNavigator} from 'react-navigation-stack';
import {createBottomTabNavigator} from 'react-navigation-tabs';
import {createAppContainer} from 'react-navigation';

const HomeStack = createStackNavigator({
  Home: {screen: HomeScreen},
  Detail: {screen: DetailScreen},
});
const SettingStack = createStackNavigator({
  Setting: {screen: SettingScreen},
  Detail: {screen: DetailScreen},
});
const TabnavigatorConfigs = {
  animationEnabled: true,
  tabBarOptions: {
    activeBackgroundColor: 'red',
    inactiveBackgroundColor: '#fff',
    activeTintColor: '#405BDB',
    inactiveTintColor: '#9B9B9B',
  },
};
const tab = createBottomTabNavigator(
  {
    Home: {screen: HomeStack},
    Setting: {screen: SettingStack},
  },
  TabnavigatorConfigs,
);
const App = createAppContainer(tab);
AppRegistry.registerComponent(appName, () => App);
